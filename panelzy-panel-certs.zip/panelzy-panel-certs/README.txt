PanelZy — panel mTLS client certs for the NEW regions
(nl, lon, sydney, dubai, dallas)
=====================================================

These regions use the CA "PanelZy-nl-CA" — a DIFFERENT CA than utah
(utah uses "panelzy-utah-ca"). The panel needs BOTH CAs trusted, and a
client cert per CA, to talk to all regions.

Files:
  ca.crt                      CA cert for the new regions (PanelZy-nl-CA).
                              Add to the panel's trusted-CA bundle so it
                              accepts these regions' vm-master certs.
  panel-client.crt            Panel's client cert (CN=panel-prod), signed
                              by PanelZy-nl-CA. Present this on mTLS calls.
  panel-client.key            Its private key. KEEP SECRET (mode 0600).
  panel-client-fullchain.crt  client cert + CA, concatenated (some stacks
                              want the chain in one file).

When is this needed?
  - vm-master gRPC control plane (:9450) is mTLS -> needs these certs.
  - vm-master HTTP admin API (:9460) uses X-Hypervisor-Token, NOT mTLS
    -> for IP-pool admin the panel just needs the token, not these certs.

Region endpoints (gRPC :9450 / HTTP admin :9460):
  nl      107.189.15.39
  lon     104.194.128.17
  sydney  45.61.167.12
  dubai   45.59.118.12
  dallas  172.86.120.45

Shared admin-API token (HTTP :9460):
  X-Hypervisor-Token: qbyvQVQZyGMR9t4HgLY7NgChxVeNLYMosR0naHoT

Validity: client cert good for 825 days. Rotate via mkclient.sh against
PanelZy-nl-CA before expiry.
